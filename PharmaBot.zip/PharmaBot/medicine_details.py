class MedicineDetails:
    def __init__(self,name = None,type = None,grams = None,expiration_date = None):
        self.name = name
        self.type = type
        self.grams = grams
        self.expiration_date = expiration_date