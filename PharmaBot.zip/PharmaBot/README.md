# PharmaBot
bot to help the user understand the information relating to a medicine for its intake.
