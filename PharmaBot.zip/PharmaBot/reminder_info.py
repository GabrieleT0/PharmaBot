class ReminderInfo:
    def __init__(self,medicine_name = None,time = None):
        self.medicine_name = medicine_name
        self.time = time
