class LocationInfo:
    def __init__(self,location_name = None,address = None,house_number = None,cap = None):
        self.location_name = location_name
        self.address = address
        self.house_number = house_number
        self.cap = cap
                                            